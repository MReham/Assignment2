import 'package:flutter/material.dart';
import 'table_screen.dart';

class InputListScreen extends StatelessWidget {
  final TextEditingController _username = TextEditingController();
  final TextEditingController _phoneNumber = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Inputs & List Screen"),
        backgroundColor: Colors.amber,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: _username,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                labelText: "User Name",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _phoneNumber,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Phone Number",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  ListTile(
                    leading: Icon(Icons.person),
                    title: Text("Item 1: View Profile"),
                  ),
                  ListTile(
                    leading: Icon(Icons.settings),
                    title: Text("Item 2: Settings Panel"),
                  ),
                  ListTile(
                    leading: Icon(Icons.notifications),
                    title: Text("Item 3: Notification Hub"),
                  ),
                  ListTile(
                    leading: Icon(Icons.help),
                    title: Text("Item 4: Support Center"),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TableScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.red,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
              child: Text("View Table"),
            ),
          ],
        ),
      ),
    );
  }
}
