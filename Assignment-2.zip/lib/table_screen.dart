import 'package:flutter/material.dart';

class TableScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Table Screen"),
        backgroundColor: Colors.amber,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Container(
          child: Table(
            border: TableBorder.all(color: Colors.red, width: 1.5),
            columnWidths: const {
              0: FlexColumnWidth(2),
              1: FlexColumnWidth(2),
              2: FlexColumnWidth(1.5),
            },
            children: [
              TableRow(
                decoration: BoxDecoration(color: Colors.grey[200]),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Name",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Major",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Level",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                ],
              ),
              TableRow(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Reham"),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Computer Science"),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Level 3"),
                  ),
                ],
              ),
              TableRow(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Mohammed"),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Software Systems"),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Level 4"),
                  ),
                ],
              ),
              TableRow(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Foud"),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("IT"),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Level 4"),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
